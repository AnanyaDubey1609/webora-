export type ServiceIconKey =
  | 'layout'
  | 'building'
  | 'graduation'
  | 'utensils'
  | 'shopping'
  | 'user'
  | 'cpu';

export interface ServiceItem {
  id: string;
  number: string;
  title: string;
  description: string;
  deliverables: string[];
  icon: ServiceIconKey;
  featured?: boolean;
}

export interface ProjectItem {
  id: string;
  title: string;
  category: string;
  description: string;
  technologies: string[];
  screenshot: string;
  liveDemoUrl?: string;
  interactiveDemoType?: 'smite-bite' | 'hospital-portal';
  highlights?: string[];
  isCustom?: boolean;
}

export interface WhyChooseItem {
  id: string;
  title: string;
  description: string;
  icon: 'sparkles' | 'code' | 'smartphone' | 'layers' | 'heart' | 'gauge';
}

export interface ProcessStep {
  step: string;
  title: string;
  description: string;
  outcome: string;
}

export interface FounderProfile {
  name: string;
  role: string;
  education: string;
  email: string;
  location: string;
  portrait: string;
  introParagraphs: string[];
  interests: string[];
  skills: {
    group: string;
    items: string[];
  }[];
  social: {
    instagram: string;
    email: string;
  };
}
