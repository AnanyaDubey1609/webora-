import { useState } from 'react';
import { AboutSection } from './components/AboutSection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { HeroSection } from './components/HeroSection';
import { Navbar } from './components/Navbar';
import { ParticleBackground } from './components/ParticleBackground';
import { ProjectsSection } from './components/ProjectsSection';
import { ServicesSection } from './components/ServicesSection';
import { WhyChooseSection } from './components/WhyChooseSection';
import { WorkProcessSection } from './components/WorkProcessSection';
import { SERVICES } from './data/agencyData';

export default function App() {
  const [selectedProjectType, setSelectedProjectType] = useState<string>(SERVICES[0].title);

  const scrollToContact = (projectType?: string) => {
    if (projectType) {
      setSelectedProjectType(projectType);
    }
    const el = document.getElementById('contact');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="relative min-h-screen bg-[#050508] text-white">
      <ParticleBackground />
      <Navbar onStartProject={() => scrollToContact()} />

      <main>
        <HeroSection onStartProject={() => scrollToContact()} />
        <AboutSection />
        <ServicesSection onSelectService={(title) => scrollToContact(title)} />
        <ProjectsSection />
        <WhyChooseSection />
        <WorkProcessSection />
        <ContactSection preselectedProjectType={selectedProjectType} />
      </main>

      <Footer />
    </div>
  );
}
