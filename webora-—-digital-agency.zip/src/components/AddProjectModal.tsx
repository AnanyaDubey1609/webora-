import { FormEvent, useEffect, useState } from 'react';
import { X } from 'lucide-react';
import { PROJECT_SCREENSHOT_PRESETS } from '../data/agencyData';
import { ProjectItem } from '../types/agency';

interface AddProjectModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddProject: (project: ProjectItem) => Promise<void>;
}

export function AddProjectModal({ isOpen, onClose, onAddProject }: AddProjectModalProps) {
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState('Web Application');
  const [description, setDescription] = useState('');
  const [technologiesInput, setTechnologiesInput] = useState('React.js, Tailwind CSS, Node.js');
  const [screenshot, setScreenshot] = useState(PROJECT_SCREENSHOT_PRESETS[0].url);
  const [liveDemoUrl, setLiveDemoUrl] = useState('');
  const [error, setError] = useState('');
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    if (!isOpen) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError('');

    if (title.trim().length < 2) {
      setError('Please enter a project title (at least 2 characters).');
      return;
    }
    if (description.trim().length < 10) {
      setError('Please enter a concise project description (at least 10 characters).');
      return;
    }

    const technologies = technologiesInput
      .split(',')
      .map((item) => item.trim())
      .filter(Boolean);

    setIsSaving(true);
    try {
      await onAddProject({
        id: `custom-${Date.now()}`,
        title: title.trim(),
        category: category.trim(),
        description: description.trim(),
        technologies: technologies.length > 0 ? technologies : ['React.js', 'Tailwind CSS'],
        screenshot: screenshot.trim() || PROJECT_SCREENSHOT_PRESETS[0].url,
        liveDemoUrl: liveDemoUrl.trim() || undefined,
        highlights: ['Custom WEBORA Build', 'Responsive Layout'],
        isCustom: true,
      });

      setTitle('');
      setDescription('');
      setLiveDemoUrl('');
      onClose();
    } catch {
      setError('Could not save the project right now. Please try again.');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-md"
      role="dialog"
      aria-modal="true"
      aria-labelledby="add-project-modal-title"
      onClick={onClose}
    >
      <div
        className="glass-panel max-h-[90vh] w-full max-w-xl overflow-y-auto rounded-2xl p-6 sm:p-7"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between border-b border-purple-500/20 pb-4">
          <div>
            <p className="font-mono text-xs uppercase tracking-widest text-purple-400">
              Dynamic Showcase Manager
            </p>
            <h3 id="add-project-modal-title" className="mt-1 font-display text-xl font-bold text-white">
              Add New Project
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="flex h-10 w-10 items-center justify-center rounded-lg border border-purple-500/30 bg-purple-950/30 text-slate-300 transition-colors hover:border-purple-400 hover:text-white cursor-pointer"
            aria-label="Close add project form"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mt-5 space-y-4">
          {error && (
            <div className="rounded-lg border border-rose-500/40 bg-rose-950/40 px-4 py-2.5 text-xs text-rose-200">
              {error}
            </div>
          )}

          <div>
            <label htmlFor="proj-title" className="block text-xs font-medium text-slate-200">
              Project Title
            </label>
            <input
              id="proj-title"
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g., Coaching Institute Learning Portal"
              className="mt-1.5 w-full rounded-lg border border-purple-500/25 bg-[#090612] px-3.5 py-2.5 text-sm text-white placeholder-slate-500 focus:border-purple-400 focus:outline-none"
            />
          </div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <label htmlFor="proj-category" className="block text-xs font-medium text-slate-200">
                Category
              </label>
              <select
                id="proj-category"
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="mt-1.5 w-full rounded-lg border border-purple-500/25 bg-[#090612] px-3.5 py-2.5 text-sm text-white focus:border-purple-400 focus:outline-none"
              >
                <option value="Web Application">Web Application</option>
                <option value="Business Website">Business Website</option>
                <option value="Food Tech">Food Tech</option>
                <option value="Healthcare">Healthcare</option>
                <option value="E-Commerce">E-Commerce</option>
                <option value="IT Project">IT Project</option>
              </select>
            </div>

            <div>
              <label htmlFor="proj-preset" className="block text-xs font-medium text-slate-200">
                Preview Visual Preset
              </label>
              <select
                id="proj-preset"
                value={screenshot}
                onChange={(e) => setScreenshot(e.target.value)}
                className="mt-1.5 w-full rounded-lg border border-purple-500/25 bg-[#090612] px-3.5 py-2.5 text-sm text-white focus:border-purple-400 focus:outline-none"
              >
                {PROJECT_SCREENSHOT_PRESETS.map((preset) => (
                  <option key={preset.url} value={preset.url}>
                    {preset.label}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label htmlFor="proj-desc" className="block text-xs font-medium text-slate-200">
              Project Description
            </label>
            <textarea
              id="proj-desc"
              rows={3}
              required
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Summarize the project purpose, architecture, and user features..."
              className="mt-1.5 w-full rounded-lg border border-purple-500/25 bg-[#090612] px-3.5 py-2.5 text-sm text-white placeholder-slate-500 focus:border-purple-400 focus:outline-none"
            />
          </div>

          <div>
            <label htmlFor="proj-tech" className="block text-xs font-medium text-slate-200">
              Technologies Used (comma-separated)
            </label>
            <input
              id="proj-tech"
              type="text"
              value={technologiesInput}
              onChange={(e) => setTechnologiesInput(e.target.value)}
              placeholder="React.js, Tailwind CSS, Node.js, MongoDB"
              className="mt-1.5 w-full rounded-lg border border-purple-500/25 bg-[#090612] px-3.5 py-2.5 text-sm text-white placeholder-slate-500 focus:border-purple-400 focus:outline-none"
            />
          </div>

          <div>
            <label htmlFor="proj-demo" className="block text-xs font-medium text-slate-200">
              Live Demo URL (optional)
            </label>
            <input
              id="proj-demo"
              type="url"
              value={liveDemoUrl}
              onChange={(e) => setLiveDemoUrl(e.target.value)}
              placeholder="https://your-demo.vercel.app"
              className="mt-1.5 w-full rounded-lg border border-purple-500/25 bg-[#090612] px-3.5 py-2.5 text-sm text-white placeholder-slate-500 focus:border-purple-400 focus:outline-none"
            />
          </div>

          <div className="flex items-center justify-end gap-3 border-t border-purple-500/15 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="rounded-lg border border-purple-500/25 px-4 py-2 text-xs font-semibold text-slate-300 transition-colors hover:border-purple-400 hover:text-white cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSaving}
              className="rounded-lg px-5 py-2 text-xs font-semibold text-white purple-glow-btn disabled:opacity-60 cursor-pointer"
            >
              {isSaving ? 'Saving...' : 'Publish to Showcase'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
