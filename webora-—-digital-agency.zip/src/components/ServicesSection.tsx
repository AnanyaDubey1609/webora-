import { motion } from 'motion/react';
import {
  ArrowUpRight,
  Building2,
  Cpu,
  GraduationCap,
  LayoutGrid,
  ShoppingBag,
  UserCheck,
  UtensilsCrossed,
} from 'lucide-react';
import { SERVICES } from '../data/agencyData';
import { ServiceIconKey } from '../types/agency';

const ICON_MAP: Record<ServiceIconKey, typeof LayoutGrid> = {
  layout: LayoutGrid,
  building: Building2,
  graduation: GraduationCap,
  utensils: UtensilsCrossed,
  shopping: ShoppingBag,
  user: UserCheck,
  cpu: Cpu,
};

interface ServicesSectionProps {
  onSelectService: (serviceTitle: string) => void;
}

export function ServicesSection({ onSelectService }: ServicesSectionProps) {
  return (
    <section id="services" className="relative z-10 py-20 sm:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col justify-between gap-4 border-b border-purple-500/15 pb-8 md:flex-row md:items-end">
          <div className="max-w-2xl">
            <p className="font-mono text-xs font-medium uppercase tracking-widest text-purple-400">
              Capabilities
            </p>
            <h2 className="mt-2 font-display text-3xl font-bold tracking-tight text-white text-balance sm:text-4xl">
              Our Services
            </h2>
            <p className="mt-3 text-base leading-relaxed text-slate-300">
              Tailored digital solutions engineered from concept to launch for businesses, educators, restaurants, and founders.
            </p>
          </div>
          <p className="font-mono text-xs text-slate-400 whitespace-nowrap">
            07 Specialized Practice Areas
          </p>
        </div>

        {/* Asymmetric Bento Grid */}
        <div className="mt-10 grid grid-cols-1 gap-5 md:grid-cols-2 lg:grid-cols-3">
          {SERVICES.map((service, index) => {
            const Icon = ICON_MAP[service.icon];
            const isFeatured = Boolean(service.featured);

            return (
              <motion.article
                key={service.id}
                initial={{ opacity: 0, y: 18 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-60px' }}
                transition={{
                  duration: 0.45,
                  delay: Math.min(index * 0.05, 0.3),
                  ease: [0.16, 1, 0.3, 1],
                }}
                className={`glass-panel neon-border-hover group flex flex-col justify-between rounded-2xl p-6 sm:p-7 ${
                  isFeatured ? 'md:col-span-2 lg:col-span-2' : ''
                }`}
              >
                <div>
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex h-12 w-12 items-center justify-center rounded-xl border border-purple-500/35 bg-purple-950/50 text-purple-300 transition-colors group-hover:border-purple-400/75 group-hover:bg-purple-900/60 group-hover:text-white">
                      <Icon className="h-5 w-5" aria-hidden="true" />
                    </div>
                    <span className="font-mono text-xs font-medium tabular-nums text-purple-400/80">
                      {service.number}
                    </span>
                  </div>

                  <h3 className="mt-5 font-display text-xl font-bold text-white">
                    {service.title}
                  </h3>

                  <p className="mt-2.5 text-sm leading-relaxed text-slate-300 sm:text-[15px]">
                    {service.description}
                  </p>
                </div>

                <div className="mt-6 flex flex-wrap items-center justify-between gap-4 border-t border-purple-500/15 pt-4">
                  <p className="text-xs text-slate-400">
                    {service.deliverables.join(' · ')}
                  </p>
                  <button
                    type="button"
                    onClick={() => onSelectService(service.title)}
                    className="inline-flex items-center gap-1 text-xs font-semibold text-purple-300 transition-colors hover:text-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-purple-400 whitespace-nowrap shrink-0 cursor-pointer"
                  >
                    <span>Start Project</span>
                    <ArrowUpRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" aria-hidden="true" />
                  </button>
                </div>
              </motion.article>
            );
          })}
        </div>
      </div>
    </section>
  );
}
