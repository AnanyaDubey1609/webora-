import { motion } from 'motion/react';
import { ArrowRight, Sparkles } from 'lucide-react';
import { BRAND_INFO } from '../data/agencyData';
import { ImageWithFallback } from './ImageWithFallback';
import { WeboraLogo } from './WeboraLogo';

interface HeroSectionProps {
  onStartProject: () => void;
}

export function HeroSection({ onStartProject }: HeroSectionProps) {
  return (
    <section
      id="home"
      className="relative z-10 overflow-hidden pt-14 pb-20 sm:pt-20 sm:pb-28 lg:pt-24 lg:pb-32"
    >
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 items-stretch gap-12 lg:grid-cols-12 lg:gap-10">
          {/* Left Content Column */}
          <div className="flex flex-col justify-center lg:col-span-6">
            <motion.div
              initial={{ opacity: 0, y: 14 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
              className="mb-6 flex items-center gap-4"
            >
              <WeboraLogo animated size="lg" showWordmark={false} />
              <div className="text-sm font-medium tracking-wide text-purple-200/90">
                <span>{BRAND_INFO.tagline}</span>
                <span className="mx-2 text-purple-400/70" aria-hidden="true">
                  ·
                </span>
                <span className="text-slate-300">{BRAND_INFO.slogan}</span>
              </div>
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 18 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.55, delay: 0.08, ease: [0.16, 1, 0.3, 1] }}
              className="font-display text-[clamp(2.5rem,5vw,4.25rem)] leading-[1.04] font-extrabold tracking-tight text-balance"
            >
              <span className="block text-slate-200">INTRODUCING</span>
              <span className="text-gradient-purple block">WEBORA</span>
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.55, delay: 0.16, ease: [0.16, 1, 0.3, 1] }}
              className="mt-5 max-w-xl font-display text-xl font-semibold leading-snug text-purple-100 sm:text-2xl"
            >
              {BRAND_INFO.heroSubheading}
            </motion.p>

            <motion.p
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.55, delay: 0.22, ease: [0.16, 1, 0.3, 1] }}
              className="mt-4 max-w-xl text-base leading-relaxed text-slate-300 sm:text-lg"
            >
              {BRAND_INFO.heroDescription}
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.55, delay: 0.28, ease: [0.16, 1, 0.3, 1] }}
              className="mt-8 flex flex-wrap items-center gap-4"
            >
              <button
                type="button"
                onClick={onStartProject}
                className="inline-flex min-h-[44px] items-center gap-2 rounded-xl px-6 py-3 text-sm font-semibold text-white purple-glow-btn focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-purple-400 whitespace-nowrap shrink-0 cursor-pointer"
              >
                <span>Start Your Project</span>
                <ArrowRight className="h-4 w-4" aria-hidden="true" />
              </button>

              <a
                href="#services"
                className="inline-flex min-h-[44px] items-center gap-2 rounded-xl border border-purple-400/35 bg-purple-950/25 px-6 py-3 text-sm font-semibold text-purple-100 transition-colors hover:border-purple-400/75 hover:bg-purple-900/40 hover:text-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-purple-400 whitespace-nowrap shrink-0"
              >
                <Sparkles className="h-4 w-4 text-purple-300" aria-hidden="true" />
                <span>Explore Our Services</span>
              </a>
            </motion.div>

            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.6, delay: 0.38 }}
              className="mt-10 flex flex-wrap items-center gap-x-4 gap-y-2 border-t border-purple-500/15 pt-6 text-xs font-medium text-slate-400 sm:text-sm"
            >
              <span>Responsive UI/UX Design</span>
              <span aria-hidden="true" className="text-purple-500/60">
                /
              </span>
              <span>Full-Stack Web Engineering</span>
              <span aria-hidden="true" className="text-purple-500/60">
                /
              </span>
              <span>Custom Digital Products</span>
            </motion.div>
          </div>

          {/* Right Visual Column */}
          <motion.div
            initial={{ opacity: 0, scale: 0.96 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.7, delay: 0.14, ease: [0.16, 1, 0.3, 1] }}
            className="relative flex items-stretch lg:col-span-6"
          >
            <div className="glass-panel neon-border-hover relative w-full overflow-hidden rounded-2xl p-2">
              <div className="relative aspect-[16/10] w-full overflow-hidden rounded-xl lg:aspect-auto lg:h-full lg:min-h-[420px]">
                <ImageWithFallback
                  src={BRAND_INFO.heroImage}
                  alt="WEBORA futuristic dark obsidian and neon purple architectural digital sculpture"
                  className="h-full w-full object-cover"
                  fallbackTitle="WEBORA Digital Architecture"
                />
                <div
                  className="pointer-events-none absolute inset-0 bg-gradient-to-t from-[#050508]/85 via-transparent to-purple-950/20"
                  aria-hidden="true"
                />
                <div className="absolute right-5 bottom-5 left-5 flex flex-wrap items-end justify-between gap-4">
                  <div>
                    <p className="font-mono text-xs uppercase tracking-wider text-purple-300">
                      Digital Agency Studio
                    </p>
                    <p className="mt-1 font-display text-lg font-semibold text-white">
                      {BRAND_INFO.tagline}
                    </p>
                  </div>
                  <a
                    href="#projects"
                    className="rounded-lg border border-purple-400/35 bg-[#090612]/80 px-3.5 py-2 text-xs font-medium text-purple-100 backdrop-blur-md transition-colors hover:border-purple-400 hover:text-white whitespace-nowrap shrink-0"
                  >
                    View Selected Work
                  </a>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
