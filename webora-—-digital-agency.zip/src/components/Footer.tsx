import { Instagram, Mail } from 'lucide-react';
import { BRAND_INFO, FOUNDER_PROFILE, SERVICES } from '../data/agencyData';
import { WeboraLogo } from './WeboraLogo';

export function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="relative z-10 border-t border-purple-500/20 bg-[#040307] pt-16 pb-10">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-10 md:grid-cols-2 lg:grid-cols-12">
          {/* Brand Summary */}
          <div className="lg:col-span-4">
            <a href="#home" aria-label="WEBORA Home" className="inline-block">
              <WeboraLogo size="md" />
            </a>
            <p className="mt-4 font-display text-base font-semibold text-purple-200">
              {BRAND_INFO.tagline}
            </p>
            <p className="mt-1 text-sm text-slate-400">{BRAND_INFO.slogan}</p>
            <p className="mt-4 max-w-sm text-xs leading-relaxed text-slate-400">
              Creative digital agency building responsive websites, modern interfaces, and tailored software solutions.
            </p>
          </div>

          {/* Quick Links */}
          <div className="lg:col-span-2">
            <h3 className="font-display text-sm font-semibold text-white">Quick Links</h3>
            <ul className="mt-4 space-y-2.5 text-sm text-slate-400">
              <li>
                <a href="#home" className="transition-colors hover:text-purple-300">
                  Home
                </a>
              </li>
              <li>
                <a href="#about" className="transition-colors hover:text-purple-300">
                  About
                </a>
              </li>
              <li>
                <a href="#services" className="transition-colors hover:text-purple-300">
                  Services
                </a>
              </li>
              <li>
                <a href="#projects" className="transition-colors hover:text-purple-300">
                  Projects
                </a>
              </li>
              <li>
                <a href="#contact" className="transition-colors hover:text-purple-300">
                  Contact
                </a>
              </li>
            </ul>
          </div>

          {/* Our Services */}
          <div className="lg:col-span-3">
            <h3 className="font-display text-sm font-semibold text-white">Our Services</h3>
            <ul className="mt-4 space-y-2.5 text-sm text-slate-400">
              {SERVICES.map((service) => (
                <li key={service.id}>
                  <a href="#services" className="transition-colors hover:text-purple-300">
                    {service.title}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact & Social */}
          <div className="lg:col-span-3">
            <h3 className="font-display text-sm font-semibold text-white">
              Contact Information
            </h3>
            <div className="mt-4 space-y-2.5 text-sm text-slate-400">
              <p>
                <a
                  href={`mailto:${FOUNDER_PROFILE.email}`}
                  className="text-purple-200 transition-colors hover:text-white"
                >
                  {FOUNDER_PROFILE.email}
                </a>
              </p>
              <p>{FOUNDER_PROFILE.location}</p>
            </div>

            <div className="mt-5 flex items-center gap-3">
              <a
                href={FOUNDER_PROFILE.social.instagram}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="WEBORA on Instagram"
                className="flex h-10 w-10 items-center justify-center rounded-lg border border-purple-500/25 bg-purple-950/25 text-slate-300 transition-colors hover:border-purple-400 hover:text-white"
              >
                <Instagram className="h-4 w-4" />
              </a>
              <a
                href={FOUNDER_PROFILE.social.email}
                aria-label="Email WEBORA"
                className="flex h-10 w-10 items-center justify-center rounded-lg border border-purple-500/25 bg-purple-950/25 text-slate-300 transition-colors hover:border-purple-400 hover:text-white"
              >
                <Mail className="h-4 w-4" />
              </a>
            </div>
          </div>
        </div>

        <div className="mt-12 flex flex-col items-center justify-between gap-4 border-t border-purple-500/15 pt-8 text-xs text-slate-500 sm:flex-row">
          <p>&copy; {currentYear} WEBORA. All rights reserved.</p>
          <p>{BRAND_INFO.tagline}</p>
        </div>
      </div>
    </footer>
  );
}
