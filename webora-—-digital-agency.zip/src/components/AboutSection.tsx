import { motion } from 'motion/react';
import { Compass, Layers, Zap } from 'lucide-react';
import { BRAND_INFO } from '../data/agencyData';
import { ImageWithFallback } from './ImageWithFallback';

const AGENCY_PILLARS = [
  {
    icon: Compass,
    title: 'Design-First Precision',
    detail: 'Structured user journeys and tailored visual systems built around your audience.',
  },
  {
    icon: Layers,
    title: 'Full-Stack Execution',
    detail: 'Clean React interfaces backed by scalable Node.js, Express, and database workflows.',
  },
  {
    icon: Zap,
    title: 'Built for Growth',
    detail: 'Fast page loads, semantic SEO structure, and responsive mobile adaptability.',
  },
];

export function AboutSection() {
  return (
    <section id="about" className="relative z-10 py-20 sm:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 items-stretch gap-10 lg:grid-cols-12 lg:gap-12">
          {/* Studio Image Column */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-80px' }}
            transition={{ duration: 0.55, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-6"
          >
            <div className="glass-panel neon-border-hover h-full overflow-hidden rounded-2xl p-2">
              <div className="relative aspect-[16/10] w-full overflow-hidden rounded-xl lg:aspect-auto lg:h-full lg:min-h-[380px]">
                <ImageWithFallback
                  src={BRAND_INFO.studioImage}
                  alt="WEBORA creative digital agency studio environment"
                  className="h-full w-full object-cover"
                  fallbackTitle="WEBORA Creative Studio"
                />
                <div
                  className="pointer-events-none absolute inset-0 bg-gradient-to-t from-[#050508]/85 via-black/20 to-transparent"
                  aria-hidden="true"
                />
                <div className="absolute bottom-5 left-5 right-5 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-200">
                  <span className="font-medium text-purple-200">{BRAND_INFO.slogan}</span>
                  <span className="font-mono text-slate-300">{BRAND_INFO.tagline}</span>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Narrative Column */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-80px' }}
            transition={{ duration: 0.55, ease: [0.16, 1, 0.3, 1] }}
            className="flex flex-col justify-center lg:col-span-6"
          >
            <p className="font-mono text-xs font-medium uppercase tracking-widest text-purple-400">
              Agency Vision
            </p>
            <h2 className="mt-2 font-display text-3xl font-bold tracking-tight text-white text-balance sm:text-4xl">
              {BRAND_INFO.aboutHeading}
            </h2>

            <div className="mt-5 space-y-4 text-base leading-relaxed text-slate-300 sm:text-lg">
              {BRAND_INFO.aboutParagraphs.map((paragraph, index) => (
                <p key={index}>{paragraph}</p>
              ))}
            </div>

            <div className="mt-8 grid grid-cols-1 gap-4 border-t border-purple-500/20 pt-8 sm:grid-cols-3">
              {AGENCY_PILLARS.map((pillar) => {
                const Icon = pillar.icon;
                return (
                  <div key={pillar.title} className="space-y-2">
                    <div className="inline-flex h-9 w-9 items-center justify-center rounded-lg border border-purple-500/30 bg-purple-950/40 text-purple-300">
                      <Icon className="h-4 w-4" aria-hidden="true" />
                    </div>
                    <h3 className="font-display text-sm font-semibold text-white">
                      {pillar.title}
                    </h3>
                    <p className="text-xs leading-relaxed text-slate-400">
                      {pillar.detail}
                    </p>
                  </div>
                );
              })}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
