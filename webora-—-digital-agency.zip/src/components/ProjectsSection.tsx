import { useEffect, useMemo, useState } from 'react';
import { motion } from 'motion/react';
import { ExternalLink, Plus, Trash2 } from 'lucide-react';
import { INITIAL_PROJECTS } from '../data/agencyData';
import { ProjectItem } from '../types/agency';
import { AddProjectModal } from './AddProjectModal';
import { ImageWithFallback } from './ImageWithFallback';
import { ProjectPreviewModal } from './ProjectPreviewModal';

const STORAGE_KEY = 'webora_custom_projects_v1';

export function ProjectsSection() {
  const [customProjects, setCustomProjects] = useState<ProjectItem[]>([]);
  const [activeFilter, setActiveFilter] = useState<string>('All');
  const [selectedProject, setSelectedProject] = useState<ProjectItem | null>(null);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);

  // Load persisted dynamic projects from Express API with localStorage fallback
  useEffect(() => {
    let mounted = true;

    async function loadProjects() {
      try {
        const res = await fetch('/api/projects');
        if (res.ok) {
          const data = (await res.json()) as { projects?: ProjectItem[] };
          if (mounted && Array.isArray(data.projects)) {
            const normalized = data.projects.map((p) => ({ ...p, isCustom: true }));
            setCustomProjects(normalized);
            localStorage.setItem(STORAGE_KEY, JSON.stringify(normalized));
            return;
          }
        }
      } catch {
        // Fallback cleanly to localStorage when running purely statically
      }

      try {
        const saved = localStorage.getItem(STORAGE_KEY);
        if (mounted && saved) {
          setCustomProjects(JSON.parse(saved) as ProjectItem[]);
        }
      } catch {
        // Ignore malformed local cache
      }
    }

    loadProjects();
    return () => {
      mounted = false;
    };
  }, []);

  const allProjects = useMemo(
    () => [...customProjects, ...INITIAL_PROJECTS],
    [customProjects]
  );

  const categories = useMemo(() => {
    const unique = Array.from(new Set(allProjects.map((p) => p.category)));
    return ['All', ...unique];
  }, [allProjects]);

  const filteredProjects = useMemo(() => {
    if (activeFilter === 'All') return allProjects;
    return allProjects.filter((p) => p.category === activeFilter);
  }, [allProjects, activeFilter]);

  const handleAddProject = async (project: ProjectItem) => {
    let savedProject = project;
    try {
      const res = await fetch('/api/projects', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(project),
      });
      if (res.ok) {
        const data = (await res.json()) as { project?: ProjectItem };
        if (data.project) {
          savedProject = { ...data.project, isCustom: true };
        }
      }
    } catch {
      // Static fallback still persists locally
    }

    const updated = [savedProject, ...customProjects];
    setCustomProjects(updated);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
    setActiveFilter('All');
  };

  const handleRemoveCustomProject = async (id: string) => {
    try {
      await fetch(`/api/projects/${encodeURIComponent(id)}`, { method: 'DELETE' });
    } catch {
      // Ignore if running statically
    }
    const updated = customProjects.filter((p) => p.id !== id);
    setCustomProjects(updated);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  };

  return (
    <section id="projects" className="relative z-10 py-20 sm:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col justify-between gap-6 border-b border-purple-500/15 pb-8 lg:flex-row lg:items-end">
          <div className="max-w-2xl">
            <p className="font-mono text-xs font-medium uppercase tracking-widest text-purple-400">
              Selected Work
            </p>
            <h2 className="mt-2 font-display text-3xl font-bold tracking-tight text-white text-balance sm:text-4xl">
              Our Projects
            </h2>
            <p className="mt-3 text-base leading-relaxed text-slate-300">
              Real-world web applications built with responsive interfaces and functional backend architecture. New projects can be added dynamically anytime.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            {/* Interactive Category Filter Controls */}
            <div
              role="group"
              aria-label="Filter projects by category"
              className="flex flex-wrap items-center gap-1 rounded-xl border border-purple-500/20 bg-[#0b0714] p-1"
            >
              {categories.map((cat) => (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setActiveFilter(cat)}
                  className={`rounded-lg px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    activeFilter === cat
                      ? 'bg-purple-600 text-white shadow-sm'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            <button
              type="button"
              onClick={() => setIsAddModalOpen(true)}
              className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl border border-purple-400/45 bg-purple-950/40 px-4 py-2 text-xs font-semibold text-purple-100 transition-colors hover:border-purple-400 hover:bg-purple-900/55 hover:text-white whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Plus className="h-4 w-4" aria-hidden="true" />
              <span>Add Project</span>
            </button>
          </div>
        </div>

        {/* Project Cards Grid */}
        <div className="mt-10 grid grid-cols-1 gap-8 lg:grid-cols-2">
          {filteredProjects.map((project, index) => (
            <motion.article
              key={project.id}
              initial={{ opacity: 0, y: 18 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-60px' }}
              transition={{
                duration: 0.45,
                delay: Math.min(index * 0.08, 0.25),
                ease: [0.16, 1, 0.3, 1],
              }}
              className="glass-panel neon-border-hover group flex flex-col overflow-hidden rounded-2xl"
            >
              {/* Screenshot Frame */}
              <div className="relative aspect-[4/3] w-full overflow-hidden border-b border-purple-500/20 bg-[#090612]">
                <ImageWithFallback
                  src={project.screenshot}
                  alt={`${project.title} screenshot`}
                  className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-[1.03]"
                  fallbackTitle={project.title}
                />
                <div
                  className="pointer-events-none absolute inset-0 bg-gradient-to-t from-[#090612]/90 via-transparent to-transparent"
                  aria-hidden="true"
                />

                {project.isCustom && (
                  <button
                    type="button"
                    onClick={() => handleRemoveCustomProject(project.id)}
                    className="absolute top-4 right-4 inline-flex h-9 w-9 items-center justify-center rounded-lg border border-rose-500/40 bg-black/75 text-rose-300 backdrop-blur-md transition-colors hover:bg-rose-950 hover:text-white cursor-pointer"
                    aria-label={`Remove ${project.title}`}
                    title="Remove custom project"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                )}
              </div>

              {/* Project Body */}
              <div className="flex flex-1 flex-col justify-between p-6 sm:p-7">
                <div>
                  <p className="font-mono text-xs text-purple-300">
                    {project.category}
                    <span aria-hidden="true" className="mx-2 text-purple-500/60">
                      ·
                    </span>
                    <span className="text-slate-400">WEBORA Engineering</span>
                  </p>

                  <h3 className="mt-2 font-display text-xl font-bold text-white sm:text-2xl">
                    {project.title}
                  </h3>

                  <p className="mt-2.5 text-sm leading-relaxed text-slate-300 sm:text-base">
                    {project.description}
                  </p>

                  <p className="mt-4 text-xs leading-relaxed text-purple-200/85">
                    {project.technologies.join(' · ')}
                  </p>
                </div>

                {/* Working Action Buttons */}
                <div className="mt-6 flex flex-wrap items-center gap-3 border-t border-purple-500/15 pt-5">
                  <button
                    type="button"
                    onClick={() => setSelectedProject(project)}
                    className="inline-flex min-h-[42px] items-center gap-2 rounded-xl px-4 py-2 text-xs font-semibold text-white purple-glow-btn focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-purple-400 whitespace-nowrap shrink-0 cursor-pointer"
                  >
                    <span>Live Demo</span>
                    <ExternalLink className="h-3.5 w-3.5" aria-hidden="true" />
                  </button>
                </div>
              </div>
            </motion.article>
          ))}
        </div>
      </div>

      <ProjectPreviewModal
        project={selectedProject}
        onClose={() => setSelectedProject(null)}
      />

      <AddProjectModal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        onAddProject={handleAddProject}
      />
    </section>
  );
}
