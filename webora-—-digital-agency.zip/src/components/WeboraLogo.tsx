import { motion } from 'motion/react';

interface WeboraLogoProps {
  animated?: boolean;
  size?: 'sm' | 'md' | 'lg';
  showWordmark?: boolean;
}

export function WeboraLogo({
  animated = false,
  size = 'md',
  showWordmark = true,
}: WeboraLogoProps) {
  const iconDimensions =
    size === 'lg' ? 'h-12 w-12' : size === 'sm' ? 'h-7 w-7' : 'h-8 w-8';

  const textSize =
    size === 'lg' ? 'text-2xl' : size === 'sm' ? 'text-base' : 'text-lg';

  return (
    <span className="inline-flex items-center gap-2.5 whitespace-nowrap shrink-0">
      <motion.svg
        viewBox="0 0 48 48"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className={`${iconDimensions} shrink-0`}
        initial={animated ? { rotate: -6, scale: 0.92, opacity: 0 } : false}
        animate={animated ? { rotate: 0, scale: 1, opacity: 1 } : undefined}
        transition={{ duration: 0.65, ease: [0.16, 1, 0.3, 1] }}
        aria-hidden="true"
      >
        <defs>
          <linearGradient id="webora-neon-grad" x1="4" y1="4" x2="44" y2="44" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#E9D5FF" />
            <stop offset="50%" stopColor="#A855F7" />
            <stop offset="100%" stopColor="#6B21A8" />
          </linearGradient>
        </defs>
        <rect
          x="3"
          y="3"
          width="42"
          height="42"
          rx="11"
          fill="#0D0817"
          stroke="url(#webora-neon-grad)"
          strokeWidth="2"
        />
        <motion.path
          d="M12 16L17.5 32L24 19L30.5 32L36 16"
          stroke="url(#webora-neon-grad)"
          strokeWidth="2.8"
          strokeLinecap="round"
          strokeLinejoin="round"
          initial={animated ? { pathLength: 0 } : false}
          animate={animated ? { pathLength: 1 } : undefined}
          transition={{ duration: 0.9, ease: [0.16, 1, 0.3, 1], delay: 0.15 }}
        />
      </motion.svg>
      {showWordmark && (
        <span
          className={`font-display font-bold tracking-tight text-white ${textSize}`}
        >
          WEBORA
        </span>
      )}
    </span>
  );
}
