import { motion } from 'motion/react';
import { WORK_PROCESS_STEPS } from '../data/agencyData';

export function WorkProcessSection() {
  return (
    <section id="process" className="relative z-10 py-20 sm:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="max-w-2xl">
          <p className="font-mono text-xs font-medium uppercase tracking-widest text-purple-400">
            Execution Blueprint
          </p>
          <h2 className="mt-2 font-display text-3xl font-bold tracking-tight text-white text-balance sm:text-4xl">
            Our Work Process
          </h2>
          <p className="mt-3 text-base leading-relaxed text-slate-300">
            A structured five-stage workflow from initial discovery to production launch.
          </p>
        </div>

        {/* Animated Horizontal/Vertical Timeline */}
        <div className="relative mt-12">
          {/* Desktop horizontal connector line */}
          <div
            className="pointer-events-none absolute top-7 right-8 left-8 hidden h-[1px] bg-gradient-to-r from-purple-600/20 via-purple-400/60 to-purple-600/20 lg:block"
            aria-hidden="true"
          />

          <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-5">
            {WORK_PROCESS_STEPS.map((item, idx) => (
              <motion.div
                key={item.step}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-50px' }}
                transition={{
                  duration: 0.45,
                  delay: idx * 0.08,
                  ease: [0.16, 1, 0.3, 1],
                }}
                className="relative flex flex-col"
              >
                {/* Step Number Node */}
                <div className="relative z-10 mb-5 flex items-center gap-3">
                  <div className="flex h-14 w-14 items-center justify-center rounded-2xl border border-purple-400/45 bg-[#110820] font-mono text-base font-bold tabular-nums text-purple-200 shadow-[0_0_24px_-6px_rgba(168,85,247,0.55)]">
                    {item.step}
                  </div>
                  <span className="h-[1px] flex-1 bg-purple-500/25 lg:hidden" aria-hidden="true" />
                </div>

                {/* Step Card */}
                <div className="glass-panel neon-border-hover flex flex-1 flex-col justify-between rounded-2xl p-5">
                  <div>
                    <h3 className="font-display text-lg font-bold text-white">
                      {item.step} - {item.title}
                    </h3>
                    <p className="mt-2 text-sm leading-relaxed text-slate-300">
                      {item.description}
                    </p>
                  </div>
                  <p className="mt-4 border-t border-purple-500/15 pt-3 text-xs font-medium text-purple-300">
                    {item.outcome}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
