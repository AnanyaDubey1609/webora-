import { useEffect, useState } from 'react';
import {
  Calendar,
  CheckCircle2,
  ExternalLink,
  Plus,
  QrCode,
  ShoppingCart,
  Stethoscope,
  X,
} from 'lucide-react';
import { ProjectItem } from '../types/agency';
import { ImageWithFallback } from './ImageWithFallback';

interface ProjectPreviewModalProps {
  project: ProjectItem | null;
  onClose: () => void;
}

const SMITE_BITE_MENU = [
  { id: 'sb-1', name: 'Truffle Mushroom Burger', category: 'Mains', price: 249 },
  { id: 'sb-2', name: 'Crispy Paneer Bao', category: 'Starters', price: 189 },
  { id: 'sb-3', name: 'Violet Berry Cooler', category: 'Drinks', price: 129 },
  { id: 'sb-4', name: 'Herb Garlic Fries', category: 'Starters', price: 139 },
];

const HOSPITAL_DEPARTMENTS = [
  { name: 'Cardiology', doctor: 'Dr. R. Sharma', slot: '10:30 AM Today', available: true },
  { name: 'Orthopedics', doctor: 'Dr. M. Verma', slot: '12:15 PM Today', available: true },
  { name: 'Neurology', doctor: 'Dr. K. Iyer', slot: '03:00 PM Today', available: true },
  { name: 'Pediatrics', doctor: 'Dr. S. Patel', slot: '04:45 PM Today', available: true },
];

export function ProjectPreviewModal({ project, onClose }: ProjectPreviewModalProps) {
  const [cart, setCart] = useState<Record<string, number>>({ 'sb-1': 1 });
  const [orderPlaced, setOrderPlaced] = useState(false);
  const [selectedDept, setSelectedDept] = useState(HOSPITAL_DEPARTMENTS[0].name);
  const [bookedSlot, setBookedSlot] = useState(false);

  useEffect(() => {
    setOrderPlaced(false);
    setBookedSlot(false);
    setCart({ 'sb-1': 1 });
    setSelectedDept(HOSPITAL_DEPARTMENTS[0].name);
  }, [project?.id]);

  useEffect(() => {
    if (!project) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [project, onClose]);

  if (!project) return null;

  const totalItems = Object.values(cart).reduce((sum, qty) => sum + qty, 0);
  const totalAmount = SMITE_BITE_MENU.reduce(
    (sum, item) => sum + (cart[item.id] || 0) * item.price,
    0
  );

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-md"
      role="dialog"
      aria-modal="true"
      aria-labelledby="project-preview-title"
      onClick={onClose}
    >
      <div
        className="glass-panel relative max-h-[90vh] w-full max-w-3xl overflow-y-auto rounded-2xl p-6 sm:p-8"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-4 border-b border-purple-500/20 pb-4">
          <div>
            <p className="font-mono text-xs uppercase tracking-widest text-purple-400">
              Interactive Case Study · {project.category}
            </p>
            <h3
              id="project-preview-title"
              className="mt-1 font-display text-xl font-bold text-white sm:text-2xl"
            >
              {project.title}
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="flex h-10 w-10 items-center justify-center rounded-lg border border-purple-500/30 bg-purple-950/30 text-slate-300 transition-colors hover:border-purple-400 hover:text-white cursor-pointer"
            aria-label="Close project preview"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Interactive Embedded Preview for Built-in Projects */}
        {project.interactiveDemoType === 'smite-bite' ? (
          <div className="mt-6 rounded-xl border border-purple-500/25 bg-[#090612] p-5">
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-purple-500/15 pb-4">
              <div className="flex items-center gap-2.5">
                <QrCode className="h-5 w-5 text-purple-400" aria-hidden="true" />
                <div>
                  <p className="font-display text-sm font-bold text-white">
                    Smite Bite · Table 04 Live Menu
                  </p>
                  <p className="text-xs text-slate-400">Interactive QR Order Simulator</p>
                </div>
              </div>
              <div className="flex items-center gap-2 font-mono text-xs text-purple-200">
                <ShoppingCart className="h-4 w-4 text-purple-400" aria-hidden="true" />
                <span className="tabular-nums">{totalItems} items · ₹{totalAmount}</span>
              </div>
            </div>

            <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2">
              {SMITE_BITE_MENU.map((item) => {
                const count = cart[item.id] || 0;
                return (
                  <div
                    key={item.id}
                    className="flex items-center justify-between rounded-lg border border-purple-500/20 bg-[#120b22]/70 p-3"
                  >
                    <div>
                      <p className="text-sm font-semibold text-white">{item.name}</p>
                      <p className="text-xs text-slate-400">
                        {item.category} · <span className="tabular-nums text-purple-300">₹{item.price}</span>
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        setOrderPlaced(false);
                        setCart((prev) => ({ ...prev, [item.id]: (prev[item.id] || 0) + 1 }));
                      }}
                      className="inline-flex h-9 items-center gap-1 rounded-lg border border-purple-400/40 bg-purple-900/40 px-3 text-xs font-semibold text-white transition-colors hover:bg-purple-700 cursor-pointer"
                    >
                      <Plus className="h-3.5 w-3.5" aria-hidden="true" />
                      <span>{count > 0 ? `Add (${count})` : 'Add'}</span>
                    </button>
                  </div>
                );
              })}
            </div>

            <div className="mt-4 flex flex-wrap items-center justify-between gap-3 pt-2">
              {orderPlaced ? (
                <div className="flex items-center gap-2 text-sm font-medium text-emerald-300">
                  <CheckCircle2 className="h-4 w-4" aria-hidden="true" />
                  <span>Order routed to Kitchen Admin Panel for Table 04.</span>
                </div>
              ) : (
                <p className="text-xs text-slate-400">
                  Tap items to simulate customer table ordering.
                </p>
              )}

              <button
                type="button"
                disabled={totalItems === 0}
                onClick={() => setOrderPlaced(true)}
                className="rounded-lg px-4 py-2 text-xs font-semibold text-white purple-glow-btn disabled:opacity-50 cursor-pointer"
              >
                Send to Kitchen Admin
              </button>
            </div>
          </div>
        ) : project.interactiveDemoType === 'hospital-portal' ? (
          <div className="mt-6 rounded-xl border border-purple-500/25 bg-[#090612] p-5">
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-purple-500/15 pb-4">
              <div className="flex items-center gap-2.5">
                <Stethoscope className="h-5 w-5 text-purple-400" aria-hidden="true" />
                <div>
                  <p className="font-display text-sm font-bold text-white">
                    Hospital Department &amp; Appointment Lookup
                  </p>
                  <p className="text-xs text-slate-400">Interactive Healthcare Portal Preview</p>
                </div>
              </div>
              <span className="font-mono text-xs text-purple-300">24/7 Emergency Ready</span>
            </div>

            <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2">
              {HOSPITAL_DEPARTMENTS.map((dept) => {
                const isSelected = selectedDept === dept.name;
                return (
                  <button
                    key={dept.name}
                    type="button"
                    onClick={() => {
                      setSelectedDept(dept.name);
                      setBookedSlot(false);
                    }}
                    className={`flex items-center justify-between rounded-lg border p-3 text-left transition-colors cursor-pointer ${
                      isSelected
                        ? 'border-purple-400 bg-purple-900/40'
                        : 'border-purple-500/20 bg-[#120b22]/70 hover:border-purple-400/50'
                    }`}
                  >
                    <div>
                      <p className="text-sm font-semibold text-white">{dept.name}</p>
                      <p className="text-xs text-slate-400">{dept.doctor}</p>
                    </div>
                    <span className="font-mono text-xs text-purple-200 tabular-nums">
                      {dept.slot}
                    </span>
                  </button>
                );
              })}
            </div>

            <div className="mt-4 flex flex-wrap items-center justify-between gap-3 pt-2">
              {bookedSlot ? (
                <div className="flex items-center gap-2 text-sm font-medium text-emerald-300">
                  <CheckCircle2 className="h-4 w-4" aria-hidden="true" />
                  <span>Consultation slot reserved for {selectedDept}.</span>
                </div>
              ) : (
                <p className="text-xs text-slate-400">
                  Selected department: <strong className="text-white">{selectedDept}</strong>
                </p>
              )}

              <button
                type="button"
                onClick={() => setBookedSlot(true)}
                className="inline-flex items-center gap-1.5 rounded-lg px-4 py-2 text-xs font-semibold text-white purple-glow-btn cursor-pointer"
              >
                <Calendar className="h-3.5 w-3.5" aria-hidden="true" />
                <span>Reserve Consultation Slot</span>
              </button>
            </div>
          </div>
        ) : (
          <div className="mt-6 overflow-hidden rounded-xl border border-purple-500/20">
            <ImageWithFallback
              src={project.screenshot}
              alt={project.title}
              className="aspect-[16/9] w-full object-cover"
              fallbackTitle={project.title}
            />
          </div>
        )}

        <div className="mt-6 space-y-4">
          <p className="text-sm leading-relaxed text-slate-300 sm:text-base">
            {project.description}
          </p>

          {project.highlights && project.highlights.length > 0 && (
            <div>
              <h4 className="font-display text-sm font-semibold text-white">
                Key Implemented Features
              </h4>
              <ul className="mt-2 space-y-1.5 text-sm text-slate-300">
                {project.highlights.map((item, idx) => (
                  <li key={idx} className="flex items-start gap-2">
                    <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-purple-400" aria-hidden="true" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          <div className="border-t border-purple-500/15 pt-4">
            <p className="text-xs text-slate-400">
              Technologies: <span className="text-purple-200">{project.technologies.join(' · ')}</span>
            </p>
          </div>
        </div>

        {project.liveDemoUrl && (
          <div className="mt-6 flex flex-wrap items-center justify-end gap-3">
            <a
              href={project.liveDemoUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex min-h-[40px] items-center gap-2 rounded-lg px-4 py-2 text-xs font-semibold text-white purple-glow-btn"
            >
              <span>Open External Link</span>
              <ExternalLink className="h-4 w-4" aria-hidden="true" />
            </a>
          </div>
        )}
      </div>
    </div>
  );
}
