import { motion } from 'motion/react';
import {
  Code2,
  Gauge,
  HeartHandshake,
  Layers,
  Smartphone,
  Sparkles,
} from 'lucide-react';
import { WHY_CHOOSE_ITEMS } from '../data/agencyData';
import { WhyChooseItem } from '../types/agency';

const ICON_MAP: Record<WhyChooseItem['icon'], typeof Sparkles> = {
  sparkles: Sparkles,
  code: Code2,
  smartphone: Smartphone,
  layers: Layers,
  heart: HeartHandshake,
  gauge: Gauge,
};

export function WhyChooseSection() {
  return (
    <section id="why-webora" className="relative z-10 py-20 sm:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="max-w-2xl">
          <p className="font-mono text-xs font-medium uppercase tracking-widest text-purple-400">
            Agency Standards
          </p>
          <h2 className="mt-2 font-display text-3xl font-bold tracking-tight text-white text-balance sm:text-4xl">
            Why Choose WEBORA?
          </h2>
          <p className="mt-3 text-base leading-relaxed text-slate-300">
            Every website we engineer combines modern aesthetics, clean codebase structure, and real usability.
          </p>
        </div>

        <div className="mt-10 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {WHY_CHOOSE_ITEMS.map((item, idx) => {
            const Icon = ICON_MAP[item.icon];
            return (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, y: 16 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-50px' }}
                transition={{
                  duration: 0.4,
                  delay: Math.min(idx * 0.05, 0.25),
                  ease: [0.16, 1, 0.3, 1],
                }}
                className="glass-panel neon-border-hover rounded-2xl p-6"
              >
                <div className="flex h-11 w-11 items-center justify-center rounded-xl border border-purple-500/30 bg-purple-950/45 text-purple-300">
                  <Icon className="h-5 w-5" aria-hidden="true" />
                </div>
                <h3 className="mt-4 font-display text-lg font-bold text-white">
                  {item.title}
                </h3>
                <p className="mt-2 text-sm leading-relaxed text-slate-300">
                  {item.description}
                </p>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
