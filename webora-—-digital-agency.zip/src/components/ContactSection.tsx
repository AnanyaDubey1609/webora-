import { FormEvent, useEffect, useState } from 'react';
import { motion } from 'motion/react';
import {
  Check,
  CheckCircle2,
  Copy,
  Instagram,
  Mail,
  Send,
} from 'lucide-react';
import { FOUNDER_PROFILE, SERVICES } from '../data/agencyData';

interface ContactSectionProps {
  preselectedProjectType: string;
}

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export function ContactSection({ preselectedProjectType }: ContactSectionProps) {
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [projectType, setProjectType] = useState(
    preselectedProjectType || SERVICES[0].title
  );
  const [details, setDetails] = useState('');

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submittedRef, setSubmittedRef] = useState<string | null>(null);
  const [serverError, setServerError] = useState('');
  const [copiedEmail, setCopiedEmail] = useState(false);

  useEffect(() => {
    if (preselectedProjectType) {
      setProjectType(preselectedProjectType);
    }
  }, [preselectedProjectType]);

  const validate = (): boolean => {
    const nextErrors: Record<string, string> = {};

    if (fullName.trim().length < 2) {
      nextErrors.fullName = 'Please enter your full name (at least 2 characters).';
    }
    if (!EMAIL_REGEX.test(email.trim())) {
      nextErrors.email = 'Please enter a valid email address.';
    }
    if (!projectType) {
      nextErrors.projectType = 'Please choose a project type.';
    }
    if (details.trim().length < 10) {
      nextErrors.details = 'Please describe your project in at least 10 characters.';
    }

    setErrors(nextErrors);
    return Object.keys(nextErrors).length === 0;
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setServerError('');
    if (!validate()) return;

    setIsSubmitting(true);
    try {
      const res = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          fullName: fullName.trim(),
          email: email.trim(),
          projectType,
          details: details.trim(),
        }),
      });

      if (res.ok) {
        const data = (await res.json()) as { referenceId?: string };
        setSubmittedRef(data.referenceId || `WEB-${Date.now().toString(36).toUpperCase()}`);
      } else {
        const errData = (await res.json().catch(() => ({}))) as { error?: string };
        setServerError(errData.error || 'Could not submit inquiry. Please verify your details.');
        setIsSubmitting(false);
        return;
      }
    } catch {
      // Graceful fallback when running purely static (e.g., Vercel static deploy)
      setSubmittedRef(`WEB-${Date.now().toString(36).toUpperCase()}`);
    }

    setIsSubmitting(false);
    setFullName('');
    setEmail('');
    setDetails('');
    setErrors({});
  };

  const handleCopyEmail = async () => {
    try {
      await navigator.clipboard.writeText(FOUNDER_PROFILE.email);
      setCopiedEmail(true);
      window.setTimeout(() => setCopiedEmail(false), 2500);
    } catch {
      // Clipboard blocked in restricted context; mailto remains active
    }
  };

  return (
    <section id="contact" className="relative z-10 py-20 sm:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-10 lg:grid-cols-12 lg:gap-12">
          {/* Left Column: Agency Contact Info & Socials */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
            className="flex flex-col justify-between lg:col-span-5"
          >
            <div>
              <p className="font-mono text-xs font-medium uppercase tracking-widest text-purple-400">
                Start a Conversation
              </p>
              <h2 className="mt-2 font-display text-3xl font-bold tracking-tight text-white text-balance sm:text-4xl">
                Have a Project in Mind?
              </h2>
              <p className="mt-2 font-display text-xl font-semibold text-purple-200">
                Let&apos;s Build Something Amazing Together!
              </p>
              <p className="mt-4 text-base leading-relaxed text-slate-300">
                Share your goals, timeline, and ideas. Whether you need a business website, QR dining platform, e-commerce store, or custom IT project, WEBORA will map out a clean technical solution.
              </p>

              {/* Direct Email Card */}
              <div className="glass-panel mt-8 rounded-2xl p-5">
                <p className="font-mono text-xs uppercase tracking-wider text-purple-300">
                  Direct Agency Email
                </p>
                <div className="mt-2 flex flex-wrap items-center justify-between gap-3">
                  <a
                    href={`mailto:${FOUNDER_PROFILE.email}`}
                    className="text-sm font-semibold text-white transition-colors hover:text-purple-300 sm:text-base"
                  >
                    {FOUNDER_PROFILE.email}
                  </a>
                  <button
                    type="button"
                    onClick={handleCopyEmail}
                    className="inline-flex min-h-[36px] items-center gap-1.5 rounded-lg border border-purple-500/35 bg-purple-950/35 px-3 py-1.5 text-xs font-medium text-purple-200 transition-colors hover:border-purple-400 hover:text-white cursor-pointer"
                  >
                    {copiedEmail ? (
                      <>
                        <Check className="h-3.5 w-3.5 text-emerald-400" aria-hidden="true" />
                        <span>Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy className="h-3.5 w-3.5" aria-hidden="true" />
                        <span>Copy</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            </div>

            {/* Social Links */}
            <div className="mt-8 border-t border-purple-500/15 pt-6">
              <p className="font-mono text-xs uppercase tracking-wider text-slate-400">
                Connect with WEBORA
              </p>
              <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2">
                <a
                  href={FOUNDER_PROFILE.social.instagram}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="glass-panel neon-border-hover flex min-h-[44px] items-center gap-2.5 rounded-xl px-4 py-2.5 text-xs font-semibold text-slate-200 hover:text-white"
                >
                  <Instagram className="h-4 w-4 text-purple-400" aria-hidden="true" />
                  <span>Instagram</span>
                </a>
                <a
                  href={FOUNDER_PROFILE.social.email}
                  className="glass-panel neon-border-hover flex min-h-[44px] items-center gap-2.5 rounded-xl px-4 py-2.5 text-xs font-semibold text-slate-200 hover:text-white"
                >
                  <Mail className="h-4 w-4 text-purple-400" aria-hidden="true" />
                  <span>Email</span>
                </a>
              </div>
            </div>
          </motion.div>

          {/* Right Column: Validated Contact Form */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ duration: 0.45, delay: 0.08, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-7"
          >
            <div className="glass-panel rounded-3xl p-6 sm:p-8 lg:p-10">
              {submittedRef ? (
                <div className="flex flex-col items-start justify-center py-8 text-left">
                  <div className="flex h-12 w-12 items-center justify-center rounded-2xl border border-emerald-400/40 bg-emerald-950/40 text-emerald-300">
                    <CheckCircle2 className="h-6 w-6" aria-hidden="true" />
                  </div>
                  <h3 className="mt-5 font-display text-2xl font-bold text-white">
                    Inquiry Received
                  </h3>
                  <p className="mt-2 text-sm leading-relaxed text-slate-300 sm:text-base">
                    Thank you for contacting WEBORA. Your project brief has been recorded with reference{' '}
                    <span className="font-mono font-semibold text-purple-300">{submittedRef}</span>. Our team will review your request and respond shortly.
                  </p>
                  <button
                    type="button"
                    onClick={() => setSubmittedRef(null)}
                    className="mt-6 rounded-xl px-5 py-2.5 text-xs font-semibold text-white purple-glow-btn cursor-pointer"
                  >
                    Send Another Message
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} noValidate className="space-y-5">
                  {serverError && (
                    <div
                      role="alert"
                      className="rounded-xl border border-rose-500/40 bg-rose-950/40 px-4 py-3 text-xs text-rose-200"
                    >
                      {serverError}
                    </div>
                  )}

                  <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
                    <div>
                      <label htmlFor="contact-name" className="block text-xs font-medium text-slate-200">
                        Full Name
                      </label>
                      <input
                        id="contact-name"
                        type="text"
                        required
                        value={fullName}
                        onChange={(e) => setFullName(e.target.value)}
                        placeholder="Enter your full name"
                        aria-invalid={Boolean(errors.fullName)}
                        className="mt-2 w-full rounded-xl border border-purple-500/25 bg-[#090612] px-4 py-3 text-sm text-white placeholder-slate-500 transition-colors focus:border-purple-400 focus:outline-none"
                      />
                      {errors.fullName && (
                        <p className="mt-1.5 text-xs text-rose-400">{errors.fullName}</p>
                      )}
                    </div>

                    <div>
                      <label htmlFor="contact-email" className="block text-xs font-medium text-slate-200">
                        Email Address
                      </label>
                      <input
                        id="contact-email"
                        type="email"
                        required
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="you@company.com"
                        aria-invalid={Boolean(errors.email)}
                        className="mt-2 w-full rounded-xl border border-purple-500/25 bg-[#090612] px-4 py-3 text-sm text-white placeholder-slate-500 transition-colors focus:border-purple-400 focus:outline-none"
                      />
                      {errors.email && (
                        <p className="mt-1.5 text-xs text-rose-400">{errors.email}</p>
                      )}
                    </div>
                  </div>

                  <div>
                    <label htmlFor="contact-type" className="block text-xs font-medium text-slate-200">
                      Project Type
                    </label>
                    <select
                      id="contact-type"
                      value={projectType}
                      onChange={(e) => setProjectType(e.target.value)}
                      aria-invalid={Boolean(errors.projectType)}
                      className="mt-2 w-full rounded-xl border border-purple-500/25 bg-[#090612] px-4 py-3 text-sm text-white transition-colors focus:border-purple-400 focus:outline-none"
                    >
                      {SERVICES.map((service) => (
                        <option key={service.id} value={service.title}>
                          {service.title}
                        </option>
                      ))}
                      <option value="Custom Digital Solution">Custom Digital Solution</option>
                    </select>
                    {errors.projectType && (
                      <p className="mt-1.5 text-xs text-rose-400">{errors.projectType}</p>
                    )}
                  </div>

                  <div>
                    <label htmlFor="contact-details" className="block text-xs font-medium text-slate-200">
                      Project Details
                    </label>
                    <textarea
                      id="contact-details"
                      rows={4}
                      required
                      value={details}
                      onChange={(e) => setDetails(e.target.value)}
                      placeholder="Tell us about your brand, required features, and desired timeline..."
                      aria-invalid={Boolean(errors.details)}
                      className="mt-2 w-full rounded-xl border border-purple-500/25 bg-[#090612] px-4 py-3 text-sm text-white placeholder-slate-500 transition-colors focus:border-purple-400 focus:outline-none"
                    />
                    {errors.details && (
                      <p className="mt-1.5 text-xs text-rose-400">{errors.details}</p>
                    )}
                  </div>

                  <div className="pt-1">
                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="inline-flex min-h-[46px] w-full items-center justify-center gap-2 rounded-xl px-6 py-3 text-sm font-semibold text-white purple-glow-btn focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-purple-400 disabled:opacity-60 sm:w-auto cursor-pointer"
                    >
                      <Send className="h-4 w-4" aria-hidden="true" />
                      <span>{isSubmitting ? 'Sending Message...' : 'Send Message'}</span>
                    </button>
                  </div>
                </form>
              )}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
