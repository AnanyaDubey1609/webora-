import {
  FounderProfile,
  ProcessStep,
  ProjectItem,
  ServiceItem,
  WhyChooseItem,
} from '../types/agency';

export const BRAND_INFO = {
  name: 'WEBORA',
  tagline: 'We Build Your Digital Future.',
  slogan: 'Innovate • Design • Grow',
  heroHeading: 'INTRODUCING WEBORA',
  heroSubheading: 'We Turn Your Ideas Into Powerful Digital Experiences.',
  heroDescription:
    'We create modern, responsive and customized websites that help businesses build their online presence.',
  aboutHeading: 'About WEBORA',
  aboutParagraphs: [
    'WEBORA is a creative digital agency focused on designing and developing modern websites and digital experiences.',
    'Our mission is to transform ideas into powerful digital solutions through creativity, innovation and technology.',
  ],
  heroImage: '/src/assets/images/hero_webora_abstract_1795671765174.jpg',
  studioImage: '/src/assets/images/about_agency_studio_1795671766155.jpg',
};

export const SERVICES: ServiceItem[] = [
  {
    id: 'web-design-dev',
    number: '01',
    title: 'Website Design & Development',
    description:
      'End-to-end custom UI/UX architecture and full-stack web engineering built for clarity, visual polish, and reliable performance across every screen size.',
    deliverables: ['Custom UI/UX Systems', 'Full-Stack Architecture', 'SEO & Speed Optimization'],
    icon: 'layout',
    featured: true,
  },
  {
    id: 'business-websites',
    number: '02',
    title: 'Business Websites',
    description:
      'Authoritative corporate and local business websites engineered to establish credibility, showcase services, and convert visitors into inquiries.',
    deliverables: ['Lead Capture Flows', 'Service Showcases', 'Analytics Integration'],
    icon: 'building',
  },
  {
    id: 'coaching-websites',
    number: '03',
    title: 'Coaching Websites',
    description:
      'Structured digital platforms for educators, mentors, and institutes featuring course catalogs, batch details, and student enrollment workflows.',
    deliverables: ['Program Directories', 'Enrollment Forms', 'Resource Portals'],
    icon: 'graduation',
  },
  {
    id: 'restaurant-websites',
    number: '04',
    title: 'Restaurant Websites',
    description:
      'Appetite-driven dining websites with interactive digital menus, QR table ordering workflows, table reservations, and kitchen order management.',
    deliverables: ['QR Digital Menus', 'Order Management', 'Reservation Forms'],
    icon: 'utensils',
  },
  {
    id: 'ecommerce-websites',
    number: '05',
    title: 'E-Commerce Websites',
    description:
      'Conversion-focused online storefronts with clean product filtering, smooth shopping cart flows, inventory management, and mobile-first checkout.',
    deliverables: ['Product Catalogs', 'Cart & Checkout', 'Admin Inventory UI'],
    icon: 'shopping',
  },
  {
    id: 'portfolio-websites',
    number: '06',
    title: 'Portfolio Websites',
    description:
      'Editorial personal brands and interactive case-study showcases tailored for creators, developers, consultants, and freelancers.',
    deliverables: ['Case Study Layouts', 'Resume Downloads', 'Direct Inquiry Links'],
    icon: 'user',
  },
  {
    id: 'it-computer-projects',
    number: '07',
    title: 'IT & Computer Projects',
    description:
      'Practical software engineering and academic or enterprise IT systems built with modern web frameworks, databases, and clean documentation.',
    deliverables: ['Database Design', 'REST APIs', 'Clean Source Code'],
    icon: 'cpu',
  },
];

export const INITIAL_PROJECTS: ProjectItem[] = [
  {
    id: 'smite-bite',
    title: 'QR-Based Food Ordering System (Smite Bite)',
    category: 'Food Tech',
    description:
      'A digital food ordering system featuring QR-based menu access and an admin panel.',
    technologies: ['React.js', 'Tailwind CSS', 'Node.js', 'Express.js', 'MongoDB', 'QR Integration'],
    screenshot: '/src/assets/images/project_smite_bite_1795671767108.jpg',
    interactiveDemoType: 'smite-bite',
    highlights: [
      'Instant table-side QR code menu scanning with category filtering',
      'Live cart management with customizable item quantities and notes',
      'Admin control panel for menu updates and real-time order status tracking',
    ],
  },
  {
    id: 'hospital-management',
    title: 'Hospital Management Website',
    category: 'Healthcare',
    description:
      'A responsive healthcare website with hospital-related information and features.',
    technologies: ['HTML5', 'CSS3', 'JavaScript', 'React.js', 'Tailwind CSS', 'Express.js'],
    screenshot: '/src/assets/images/project_hospital_portal_1795671767369.jpg',
    interactiveDemoType: 'hospital-portal',
    highlights: [
      'Department directory covering Cardiology, Orthopedics, Neurology, and Emergency Care',
      'Doctor availability lookup and streamlined patient appointment booking flow',
      'Responsive multi-device layout designed for both desktop reception and mobile patients',
    ],
  },
];

export const FOUNDER_PROFILE: FounderProfile = {
  name: 'Annayaa Dubey',
  role: 'Founder & Developer at WEBORA',
  education: 'Diploma in Information Technology',
  email: 'dubey.ananya1609@gmail.com',
  location: 'India · Available Worldwide',
  portrait: '/src/assets/images/founder_annayaa_portrait_1795671771393.jpg',
  introParagraphs: [
    "Hello! I'm Annayaa Dubey, the Founder and Developer of WEBORA.",
    'I am pursuing a Diploma in Information Technology and have a strong interest in web development, software development and creating modern digital experiences.',
    'I enjoy building responsive, creative and user-friendly websites.',
    'My goal is to transform creative ideas into meaningful digital solutions.',
  ],
  interests: [
    'Web Development',
    'Frontend Development',
    'Backend Development',
    'Software Development',
    'UI/UX Design',
  ],
  skills: [
    {
      group: 'Frontend & UI',
      items: ['HTML5', 'CSS3', 'JavaScript', 'React.js', 'Tailwind CSS', 'Framer Motion', 'UI/UX Design'],
    },
    {
      group: 'Backend & Data',
      items: ['Node.js', 'Express.js', 'MongoDB', 'REST APIs'],
    },
    {
      group: 'Workflow & Tools',
      items: ['Git', 'GitHub', 'VS Code', 'Responsive Architecture', 'Vercel Deployment'],
    },
  ],
  social: {
    instagram: 'https://www.instagram.com',
    email: 'mailto:dubey.ananya1609@gmail.com',
  },
};

export const WHY_CHOOSE_ITEMS: WhyChooseItem[] = [
  {
    id: 'creative-design',
    title: 'Creative Design',
    description:
      'Distinctive visual identities and intentional layouts tailored to make your brand memorable rather than generic.',
    icon: 'sparkles',
  },
  {
    id: 'modern-technology',
    title: 'Modern Technology',
    description:
      'Built on proven modern stacks including React.js, Tailwind CSS, Node.js, and Express.js for long-term maintainability.',
    icon: 'code',
  },
  {
    id: 'responsive-websites',
    title: 'Responsive Websites',
    description:
      'Fluid grid architectures tested across smartphones, tablets, and wide desktop displays with zero layout breakage.',
    icon: 'smartphone',
  },
  {
    id: 'customized-solutions',
    title: 'Customized Solutions',
    description:
      'Every feature, workflow, and interface component is crafted specifically around your business model and audience.',
    icon: 'layers',
  },
  {
    id: 'user-friendly',
    title: 'User-Friendly Experience',
    description:
      'Intuitive navigation, clear call-to-actions, and accessible contrast so visitors find what they need effortlessly.',
    icon: 'heart',
  },
  {
    id: 'performance-optimization',
    title: 'Performance Optimization',
    description:
      'Lightweight bundles, GPU-composited animations, and semantic SEO structure for fast loading and search visibility.',
    icon: 'gauge',
  },
];

export const WORK_PROCESS_STEPS: ProcessStep[] = [
  {
    step: '01',
    title: 'Discover',
    description:
      'We analyze your business goals, target audience, brand voice, and core functional requirements.',
    outcome: 'Clear project scope and measurable objectives',
  },
  {
    step: '02',
    title: 'Planning',
    description:
      'We structure the site architecture, user journeys, technical stack, and content hierarchy.',
    outcome: 'Wireframe blueprint and technical roadmap',
  },
  {
    step: '03',
    title: 'Design',
    description:
      'We craft modern UI/UX layouts, responsive typography, color harmony, and interactive states.',
    outcome: 'Cohesive visual system ready for engineering',
  },
  {
    step: '04',
    title: 'Development',
    description:
      'We write clean frontend and backend code with smooth animations, form validation, and SEO metadata.',
    outcome: 'Tested, responsive production application',
  },
  {
    step: '05',
    title: 'Launch',
    description:
      'We deploy to production, verify performance and responsiveness across devices, and connect your domain.',
    outcome: 'Live website ready for growth',
  },
];

export const PROJECT_SCREENSHOT_PRESETS = [
  {
    label: 'Abstract Neon Architecture',
    url: '/src/assets/images/hero_webora_abstract_1795671765174.jpg',
  },
  {
    label: 'Digital Studio Workstation',
    url: '/src/assets/images/about_agency_studio_1795671766155.jpg',
  },
  {
    label: 'Restaurant QR Web App',
    url: '/src/assets/images/project_smite_bite_1795671767108.jpg',
  },
  {
    label: 'Healthcare Portal UI',
    url: '/src/assets/images/project_hospital_portal_1795671767369.jpg',
  },
];
