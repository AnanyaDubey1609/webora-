import dotenv from 'dotenv';
import express from 'express';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const DATA_DIR = path.resolve(__dirname, '.data');
const INQUIRIES_FILE = path.join(DATA_DIR, 'inquiries.json');
const PROJECTS_FILE = path.join(DATA_DIR, 'projects.json');

interface InquiryPayload {
  fullName: string;
  email: string;
  projectType: string;
  details: string;
}

interface StoredInquiry extends InquiryPayload {
  id: string;
  submittedAt: string;
}

interface CustomProjectPayload {
  id?: string;
  title: string;
  category: string;
  description: string;
  technologies: string[];
  screenshot: string;
  liveDemoUrl?: string;
  highlights?: string[];
}

function ensureDataDir(): void {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
}

function readJsonFile<T>(filePath: string, fallback: T): T {
  try {
    if (!fs.existsSync(filePath)) {
      return fallback;
    }
    const raw = fs.readFileSync(filePath, 'utf-8');
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

function writeJsonFile<T>(filePath: string, data: T): void {
  ensureDataDir();
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf-8');
}

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

async function startServer() {
  const app = express();
  const PORT = Number(process.env.PORT) || 3000;

  app.use(express.json({ limit: '1mb' }));

  app.get('/api/health', (_req, res) => {
    res.json({ status: 'ok', brand: 'WEBORA' });
  });

  // Retrieve custom dynamically added projects
  app.get('/api/projects', (_req, res) => {
    const customProjects = readJsonFile<CustomProjectPayload[]>(PROJECTS_FILE, []);
    res.json({ projects: customProjects });
  });

  // Add a new dynamic project
  app.post('/api/projects', (req, res) => {
    const body = req.body as Partial<CustomProjectPayload>;
    const title = typeof body.title === 'string' ? body.title.trim() : '';
    const category = typeof body.category === 'string' ? body.category.trim() : 'Web Application';
    const description = typeof body.description === 'string' ? body.description.trim() : '';
    const screenshot = typeof body.screenshot === 'string' ? body.screenshot.trim() : '';
    const technologies = Array.isArray(body.technologies)
      ? body.technologies.map((item) => String(item).trim()).filter(Boolean)
      : [];

    if (!title || title.length < 2) {
      res.status(400).json({ error: 'Project title must be at least 2 characters.' });
      return;
    }
    if (!description || description.length < 10) {
      res.status(400).json({ error: 'Project description must be at least 10 characters.' });
      return;
    }

    const newProject: CustomProjectPayload = {
      id: `custom-${Date.now()}`,
      title,
      category,
      description,
      technologies: technologies.length > 0 ? technologies : ['React', 'Tailwind CSS'],
      screenshot: screenshot || '/src/assets/images/hero_webora_abstract_1795671765174.jpg',
      liveDemoUrl: typeof body.liveDemoUrl === 'string' ? body.liveDemoUrl.trim() : '',
      highlights: Array.isArray(body.highlights)
        ? body.highlights.map((h) => String(h).trim()).filter(Boolean)
        : ['Responsive Architecture', 'Modern UI/UX'],
    };

    const existing = readJsonFile<CustomProjectPayload[]>(PROJECTS_FILE, []);
    const updated = [newProject, ...existing];
    writeJsonFile(PROJECTS_FILE, updated);

    res.status(201).json({ project: newProject });
  });

  // Remove a dynamically added project
  app.delete('/api/projects/:id', (req, res) => {
    const { id } = req.params;
    const existing = readJsonFile<CustomProjectPayload[]>(PROJECTS_FILE, []);
    const filtered = existing.filter((p) => p.id !== id);
    writeJsonFile(PROJECTS_FILE, filtered);
    res.json({ removed: id });
  });

  // Contact form submission with server-side validation
  app.post('/api/contact', (req, res) => {
    const body = req.body as Partial<InquiryPayload>;
    const fullName = typeof body.fullName === 'string' ? body.fullName.trim() : '';
    const email = typeof body.email === 'string' ? body.email.trim() : '';
    const projectType = typeof body.projectType === 'string' ? body.projectType.trim() : '';
    const details = typeof body.details === 'string' ? body.details.trim() : '';

    if (fullName.length < 2) {
      res.status(400).json({ error: 'Please enter your full name (at least 2 characters).' });
      return;
    }
    if (!EMAIL_REGEX.test(email)) {
      res.status(400).json({ error: 'Please enter a valid email address.' });
      return;
    }
    if (!projectType) {
      res.status(400).json({ error: 'Please select a project type.' });
      return;
    }
    if (details.length < 10) {
      res.status(400).json({ error: 'Please share at least 10 characters about your project.' });
      return;
    }

    const inquiry: StoredInquiry = {
      id: `INQ-${Date.now().toString(36).toUpperCase()}`,
      fullName,
      email,
      projectType,
      details,
      submittedAt: new Date().toISOString(),
    };

    const existing = readJsonFile<StoredInquiry[]>(INQUIRIES_FILE, []);
    writeJsonFile(INQUIRIES_FILE, [inquiry, ...existing]);

    res.status(201).json({
      success: true,
      referenceId: inquiry.id,
      message: 'Thank you for reaching out to WEBORA. Our team will review your project brief shortly.',
    });
  });

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`WEBORA server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start WEBORA server:', err);
  process.exit(1);
});
