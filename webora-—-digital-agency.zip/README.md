# WEBORA — Digital Agency Website

**Tagline:** We Build Your Digital Future.  
**Slogan:** Innovate • Design • Grow  
**Founder & Developer:** Annayaa Dubey (Diploma in Information Technology)

## Folder & File Structure

```text
├── index.html                          # SEO metadata, OpenGraph, Twitter Cards, JSON-LD, Fonts
├── metadata.json                       # Brand configuration
├── package.json                        # Scripts & dependencies
├── server.ts                           # Express.js API + Vite middleware server
├── vite.config.ts                      # Vite + Tailwind v4 configuration
└── src/
    ├── main.tsx                        # React 19 entry point
    ├── index.css                       # Tailwind v4 theme, glassmorphism, neon-purple utilities
    ├── App.tsx                         # Main single-page agency layout & state orchestration
    ├── types/
    │   └── agency.ts                   # TypeScript interfaces
    ├── data/
    │   └── agencyData.ts               # Services, projects, founder profile, process steps
    ├── assets/images/                  # Generated agency & project visuals
    └── components/
        ├── ParticleBackground.tsx      # Animated cosmic purple particle canvas
        ├── WeboraLogo.tsx              # Animated geometric SVG emblem & wordmark
        ├── ImageWithFallback.tsx       # Resilient media frame with styled fallback
        ├── Navbar.tsx                  # Responsive 3-zone header + mobile menu
        ├── HeroSection.tsx             # Hero showcase & primary CTAs
        ├── AboutSection.tsx            # About WEBORA & agency mission
        ├── ServicesSection.tsx         # 7 interactive service bento cards
        ├── ProjectsSection.tsx         # Dynamic filterable project showcase
        ├── ProjectPreviewModal.tsx     # Interactive Smite Bite & Hospital portal live demos
        ├── AddProjectModal.tsx         # Dynamic modal to publish new projects
        ├── FounderSection.tsx          # Annayaa Dubey profile, skills & Resume download
        ├── WhyChooseSection.tsx        # 6 agency engineering pillars
        ├── WorkProcessSection.tsx      # 01–05 animated work timeline
        ├── ContactSection.tsx          # Validated inquiry form + social links
        └── Footer.tsx                  # Links, services, contact info & copyright
```

## Run Locally in VS Code

1. Open the project folder in **VS Code** (`File -> Open Folder`).
2. Open the integrated terminal (`Ctrl + \`` or `Terminal -> New Terminal`).
3. Install dependencies:
   ```bash
   npm install
   ```
4. Start the development server:
   ```bash
   npm run dev
   ```
5. Open `http://localhost:3000` in your browser.

## Upload to GitHub

1. Create a new repository on GitHub (e.g., `webora-agency`).
2. Run in VS Code terminal:
   ```bash
   git init
   git add .
   git commit -m "Initial commit: WEBORA Digital Agency website"
   git branch -M main
   git remote add origin https://github.com/<your-username>/webora-agency.git
   git push -u origin main
   ```

## Deploy on Vercel

1. Sign in to [vercel.com](https://vercel.com) with your GitHub account.
2. Click **Add New Project** and import your `webora-agency` repository.
3. Verify the build settings (Vercel detects Vite automatically):
   - **Build Command:** `npm run build`
   - **Output Directory:** `dist`
4. Click **Deploy**.

## Connect a Custom Domain

1. In your Vercel project dashboard, open **Settings -> Domains**.
2. Enter your custom domain (e.g., `webora.in` or `www.webora.in`) and click **Add**.
3. Copy the DNS records shown by Vercel (`A` record pointing to `76.76.21.21` for apex domain, or `CNAME` pointing to `cname.vercel-dns.com` for `www`).
4. Add those DNS records in your domain registrar (GoDaddy, Namecheap, Hostinger, or Cloudflare) and wait for SSL provisioning.
